"""
Customer Segmentation using RFM Analysis
Run:  python rfm_analysis.py                 -> uses generated sample data
      python rfm_analysis.py my_orders.csv   -> uses your data
Expected columns: CustomerID, OrderID, OrderDate, Quantity, Amount
Optional customer columns: Gender, MaritalStatus, Age, Country
"""
import sys, json
import numpy as np
import pandas as pd

OUT = "."
rng = np.random.default_rng(42)

# ---------- 0. Sample data (only used when no file is given) ----------
def make_sample(n_cust=3000):
    countries = ["United States", "Australia", "United Kingdom", "Germany", "France", "Canada"]
    cust = pd.DataFrame({
        "CustomerID": np.arange(10001, 10001 + n_cust),
        "Gender": rng.choice(["Female", "Male"], n_cust),
        "MaritalStatus": rng.choice(["Married", "Single"], n_cust, p=[.55, .45]),
        "Age": rng.integers(22, 80, n_cust),
        "Country": rng.choice(countries, n_cust, p=[.35, .2, .15, .12, .1, .08]),
    })
    # latent engagement drives how often/recently/much a customer buys
    eng = rng.beta(1.2, 2.5, n_cust)
    start = pd.Timestamp("2024-01-01"); end = pd.Timestamp("2025-12-31")
    rows, oid = [], 1
    for cid, e in zip(cust.CustomerID, eng):
        n = max(1, int(rng.poisson(1 + e * 14)))
        first = start + pd.Timedelta(days=int(rng.integers(0, 700)))
        churned = rng.random() > (0.35 + e)          # low engagement -> stopped buying
        last_allowed = first + pd.Timedelta(days=int(rng.integers(30, 300))) if churned else end
        span = max((min(last_allowed, end) - first).days, 1)
        for d in sorted(rng.integers(0, span + 1, n)):
            rows.append((cid, f"SO{oid}", first + pd.Timedelta(days=int(d)),
                         int(rng.integers(1, 5)), round(float(rng.gamma(2.2, 60 + 120 * e)), 2)))
            oid += 1
    df = pd.DataFrame(rows, columns=["CustomerID", "OrderID", "OrderDate", "Quantity", "Amount"])
    # inject dirt so the cleaning step has work to do
    dirt = df.sample(60, random_state=1).copy(); dirt["Quantity"] = -1          # returns
    nulls = df.sample(40, random_state=2).copy(); nulls["CustomerID"] = np.nan
    return pd.concat([df, dirt, nulls, df.sample(80, random_state=3)]), cust

if len(sys.argv) > 1:
    raw = pd.read_csv(sys.argv[1], parse_dates=["OrderDate"]); cust = None
else:
    raw, cust = make_sample()

# ---------- 1. Clean ----------
log = {"raw_rows": len(raw)}
df = raw.drop_duplicates();                              log["after_dedupe"] = len(df)
df = df.dropna(subset=["CustomerID", "OrderDate", "Amount"]); log["after_null_drop"] = len(df)
df = df[(df.Quantity > 0) & (df.Amount > 0)];            log["after_returns_removed"] = len(df)
df["CustomerID"] = df["CustomerID"].astype(int)
log["customers"] = int(df.CustomerID.nunique())

# ---------- 2. RFM ----------
snapshot = df.OrderDate.max() + pd.Timedelta(days=1)
rfm = df.groupby("CustomerID").agg(
    Recency=("OrderDate", lambda x: (snapshot - x.max()).days),
    Frequency=("OrderID", "nunique"),
    Monetary=("Amount", "sum"),
).reset_index()
rfm["R"] = pd.qcut(rfm.Recency, 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F"] = pd.qcut(rfm.Frequency.rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M"] = pd.qcut(rfm.Monetary.rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["RFM_Score"] = rfm.R.astype(str) + rfm.F.astype(str) + rfm.M.astype(str)

# ---------- 3. Segment ----------
def segment(r):
    if r.R >= 4 and r.F >= 4: return "Loyal"
    if r.R >= 4 and r.F == 1: return "New"
    if r.R >= 3 and r.F >= 2: return "Potential Loyalist"
    if r.R <= 2 and r.F >= 3: return "Churn Risk"
    return "Hibernating"
rfm["Segment"] = rfm.apply(segment, axis=1)

# ---------- 4. Behaviour per segment ----------
order = ["Loyal", "Potential Loyalist", "New", "Churn Risk", "Hibernating"]
summ = rfm.groupby("Segment").agg(
    Customers=("CustomerID", "count"), AvgRecency=("Recency", "mean"),
    AvgFrequency=("Frequency", "mean"), AvgMonetary=("Monetary", "mean"),
    Revenue=("Monetary", "sum")).reindex(order).round(1)
summ["CustomerShare%"] = (summ.Customers / summ.Customers.sum() * 100).round(1)
summ["RevenueShare%"] = (summ.Revenue / summ.Revenue.sum() * 100).round(1)

demo = None
if cust is not None:
    m = rfm.merge(cust, on="CustomerID")
    m["AgeBand"] = pd.cut(m.Age, [0, 34, 44, 54, 64, 120], labels=["<35", "35-44", "45-54", "55-64", "65+"])
    demo = {c: pd.crosstab(m.Segment, m[c], normalize="index").mul(100).round(1).reindex(order).to_dict("index")
            for c in ["Gender", "MaritalStatus", "AgeBand", "Country"]}

# ---------- 5. Recommendations ----------
reco = {
 "Loyal": "VIP tier, early access, referral rewards. Avoid blanket discounts.",
 "Potential Loyalist": "Cross-sell and bundles; points programme to build purchase habit.",
 "New": "Welcome series; second-purchase incentive within 30 days.",
 "Churn Risk": "Personalised win-back offer, 'we miss you' email, feedback survey.",
 "Hibernating": "One low-cost reactivation attempt, then suppress to save spend."}

# ---------- 6. Export ----------
rfm.to_csv(f"{OUT}/rfm_customers.csv", index=False)
summ.to_csv(f"{OUT}/segment_summary.csv")
sample = rfm.sample(min(500, len(rfm)), random_state=1)[["Frequency", "Monetary", "Recency", "Segment"]]
monthly = df.assign(M=df.OrderDate.dt.to_period("M").astype(str)).groupby("M").Amount.sum().round(0)
json.dump({"log": log, "snapshot": str(snapshot.date()), "summary": summ.reset_index().to_dict("records"),
           "reco": reco, "demo": demo, "scatter": sample.round(1).to_dict("records"),
           "monthly": monthly.to_dict()}, open(f"{OUT}/dashboard_data.json", "w"), default=str)
print(json.dumps(log, indent=1)); print(summ.to_string())
