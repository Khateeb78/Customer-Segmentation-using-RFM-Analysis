import json, sys, numpy as np, pandas as pd
sys.argv = ["x"]
import rfm_analysis as R          # reuses the cleaned sample data (df, cust)
df, cust = R.df.copy(), R.cust.copy()
prods = ["Bikes", "Accessories", "Clothing"]
df["Product"] = df.OrderID.str[2:].astype(int).mod(3).map(dict(enumerate(prods)))
sales = df.pivot_table(index="CustomerID", columns="Product", values="Amount", aggfunc="sum", fill_value=0)[prods]
c = cust.set_index("CustomerID").join(sales, how="inner")
bands = ["18-34", "35-44", "45-54", "55-64", "65-74", "75+"]
c["Band"] = pd.cut(c.Age, [0, 34, 44, 54, 64, 74, 200], labels=bands).astype(str)
countries = sorted(c.Country.unique())
rows = [[int(r.Gender == "Male"), int(r.MaritalStatus == "Single"), bands.index(r.Band),
         countries.index(r.Country)] + [round(r[p]) for p in prods] for _, r in c.iterrows()]
json.dump({"prods": prods, "bands": bands, "countries": countries, "rows": rows},
          open("demographics_data.json", "w"))
print(len(rows), "customers;", round(sales.values.sum()), "total sales")
